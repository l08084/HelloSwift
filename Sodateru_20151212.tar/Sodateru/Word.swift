//
//  Word.swift
//  Sodateru
//
//  Created by 中安拓也 on 2015/11/14.
//  Copyright © 2015年 mycompany. All rights reserved.
//

import RealmSwift

class Word: Object {
    dynamic var english = ""
    dynamic var japanese = ""
}
